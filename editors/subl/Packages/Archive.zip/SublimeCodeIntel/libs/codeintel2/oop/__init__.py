#!/usr/bin/env python2

"""
This module includes the out-of-process support code for codeintel2

Reference: http://bugs.activestate.com/show_bug.cgi?id=93455
"""

from .driver import Driver
